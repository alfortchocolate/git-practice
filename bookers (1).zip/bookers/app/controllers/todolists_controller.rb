class TodolistsController < ApplicationController
  def new
    @list=List.new
  end
  
  def create
    list=List.new(lists_params)
    lit.save
    redirect_to
  end
  
  private
  def list_params
    params.require(:list).permit(:title,:body)
  end
end
